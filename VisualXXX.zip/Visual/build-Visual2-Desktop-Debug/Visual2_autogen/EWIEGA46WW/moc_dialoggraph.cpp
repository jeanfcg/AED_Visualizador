/****************************************************************************
** Meta object code from reading C++ file 'dialoggraph.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../Visual2/dialoggraph.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialoggraph.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_Dialoggraph_t {
    uint offsetsAndSizes[22];
    char stringdata0[12];
    char stringdata1[30];
    char stringdata2[1];
    char stringdata3[29];
    char stringdata4[38];
    char stringdata5[27];
    char stringdata6[35];
    char stringdata7[26];
    char stringdata8[30];
    char stringdata9[27];
    char stringdata10[30];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_Dialoggraph_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_Dialoggraph_t qt_meta_stringdata_Dialoggraph = {
    {
        QT_MOC_LITERAL(0, 11),  // "Dialoggraph"
        QT_MOC_LITERAL(12, 29),  // "on_pushButtonVertices_clicked"
        QT_MOC_LITERAL(42, 0),  // ""
        QT_MOC_LITERAL(43, 28),  // "on_pushButtonAristas_clicked"
        QT_MOC_LITERAL(72, 37),  // "on_pushButtonBusquedaProfunda..."
        QT_MOC_LITERAL(110, 26),  // "on_pushButtonAtras_clicked"
        QT_MOC_LITERAL(137, 34),  // "on_pushButtonBusquedaAncha_cl..."
        QT_MOC_LITERAL(172, 25),  // "on_pushButtonPrim_clicked"
        QT_MOC_LITERAL(198, 29),  // "on_pushButtonWarshall_clicked"
        QT_MOC_LITERAL(228, 26),  // "on_pushButtonFloyd_clicked"
        QT_MOC_LITERAL(255, 29)   // "on_pushButtonDijkstra_clicked"
    },
    "Dialoggraph",
    "on_pushButtonVertices_clicked",
    "",
    "on_pushButtonAristas_clicked",
    "on_pushButtonBusquedaProfunda_clicked",
    "on_pushButtonAtras_clicked",
    "on_pushButtonBusquedaAncha_clicked",
    "on_pushButtonPrim_clicked",
    "on_pushButtonWarshall_clicked",
    "on_pushButtonFloyd_clicked",
    "on_pushButtonDijkstra_clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_Dialoggraph[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   68,    2, 0x08,    1 /* Private */,
       3,    0,   69,    2, 0x08,    2 /* Private */,
       4,    0,   70,    2, 0x08,    3 /* Private */,
       5,    0,   71,    2, 0x08,    4 /* Private */,
       6,    0,   72,    2, 0x08,    5 /* Private */,
       7,    0,   73,    2, 0x08,    6 /* Private */,
       8,    0,   74,    2, 0x08,    7 /* Private */,
       9,    0,   75,    2, 0x08,    8 /* Private */,
      10,    0,   76,    2, 0x08,    9 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Dialoggraph::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_Dialoggraph.offsetsAndSizes,
    qt_meta_data_Dialoggraph,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_Dialoggraph_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Dialoggraph, std::true_type>,
        // method 'on_pushButtonVertices_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonAristas_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonBusquedaProfunda_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonAtras_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonBusquedaAncha_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonPrim_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonWarshall_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonFloyd_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonDijkstra_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Dialoggraph::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Dialoggraph *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_pushButtonVertices_clicked(); break;
        case 1: _t->on_pushButtonAristas_clicked(); break;
        case 2: _t->on_pushButtonBusquedaProfunda_clicked(); break;
        case 3: _t->on_pushButtonAtras_clicked(); break;
        case 4: _t->on_pushButtonBusquedaAncha_clicked(); break;
        case 5: _t->on_pushButtonPrim_clicked(); break;
        case 6: _t->on_pushButtonWarshall_clicked(); break;
        case 7: _t->on_pushButtonFloyd_clicked(); break;
        case 8: _t->on_pushButtonDijkstra_clicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *Dialoggraph::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Dialoggraph::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Dialoggraph.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int Dialoggraph::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
