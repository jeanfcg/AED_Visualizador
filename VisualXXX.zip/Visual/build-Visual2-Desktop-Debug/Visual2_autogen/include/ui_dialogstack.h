/********************************************************************************
** Form generated from reading UI file 'dialogstack.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGSTACK_H
#define UI_DIALOGSTACK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_DialogStack
{
public:
    QLineEdit *lineEditData;
    QTextEdit *textEditHistory;
    QPushButton *pushButtonApilar;
    QPushButton *pushButtonDesapilar;
    QLabel *labelDisplay;

    void setupUi(QDialog *DialogStack)
    {
        if (DialogStack->objectName().isEmpty())
            DialogStack->setObjectName("DialogStack");
        DialogStack->resize(400, 300);
        lineEditData = new QLineEdit(DialogStack);
        lineEditData->setObjectName("lineEditData");
        lineEditData->setGeometry(QRect(40, 40, 113, 24));
        textEditHistory = new QTextEdit(DialogStack);
        textEditHistory->setObjectName("textEditHistory");
        textEditHistory->setGeometry(QRect(50, 160, 131, 101));
        pushButtonApilar = new QPushButton(DialogStack);
        pushButtonApilar->setObjectName("pushButtonApilar");
        pushButtonApilar->setGeometry(QRect(60, 80, 80, 24));
        pushButtonDesapilar = new QPushButton(DialogStack);
        pushButtonDesapilar->setObjectName("pushButtonDesapilar");
        pushButtonDesapilar->setGeometry(QRect(59, 120, 81, 24));
        labelDisplay = new QLabel(DialogStack);
        labelDisplay->setObjectName("labelDisplay");
        labelDisplay->setGeometry(QRect(210, 20, 161, 251));

        retranslateUi(DialogStack);

        QMetaObject::connectSlotsByName(DialogStack);
    } // setupUi

    void retranslateUi(QDialog *DialogStack)
    {
        DialogStack->setWindowTitle(QCoreApplication::translate("DialogStack", "Dialog", nullptr));
        pushButtonApilar->setText(QCoreApplication::translate("DialogStack", "\302\241Crece la pila!", nullptr));
        pushButtonDesapilar->setText(QCoreApplication::translate("DialogStack", "Decrece la pila ", nullptr));
        labelDisplay->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class DialogStack: public Ui_DialogStack {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGSTACK_H
