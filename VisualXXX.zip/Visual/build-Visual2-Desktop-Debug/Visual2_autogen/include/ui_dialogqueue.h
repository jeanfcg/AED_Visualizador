/********************************************************************************
** Form generated from reading UI file 'dialogqueue.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGQUEUE_H
#define UI_DIALOGQUEUE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_DialogQueue
{
public:
    QLineEdit *lineEditData;
    QTextEdit *textEditHistory;
    QPushButton *pushButtonEnqueue;
    QPushButton *pushButtonDequeue;
    QLabel *labelDisplay;

    void setupUi(QDialog *DialogQueue)
    {
        if (DialogQueue->objectName().isEmpty())
            DialogQueue->setObjectName("DialogQueue");
        DialogQueue->resize(800, 600);
        lineEditData = new QLineEdit(DialogQueue);
        lineEditData->setObjectName("lineEditData");
        lineEditData->setGeometry(QRect(150, 140, 113, 24));
        textEditHistory = new QTextEdit(DialogQueue);
        textEditHistory->setObjectName("textEditHistory");
        textEditHistory->setGeometry(QRect(150, 210, 104, 241));
        pushButtonEnqueue = new QPushButton(DialogQueue);
        pushButtonEnqueue->setObjectName("pushButtonEnqueue");
        pushButtonEnqueue->setGeometry(QRect(100, 180, 80, 24));
        pushButtonDequeue = new QPushButton(DialogQueue);
        pushButtonDequeue->setObjectName("pushButtonDequeue");
        pushButtonDequeue->setGeometry(QRect(220, 180, 80, 24));
        labelDisplay = new QLabel(DialogQueue);
        labelDisplay->setObjectName("labelDisplay");
        labelDisplay->setGeometry(QRect(390, 60, 311, 371));

        retranslateUi(DialogQueue);

        QMetaObject::connectSlotsByName(DialogQueue);
    } // setupUi

    void retranslateUi(QDialog *DialogQueue)
    {
        DialogQueue->setWindowTitle(QCoreApplication::translate("DialogQueue", "Dialog", nullptr));
        pushButtonEnqueue->setText(QCoreApplication::translate("DialogQueue", "Enqueue", nullptr));
        pushButtonDequeue->setText(QCoreApplication::translate("DialogQueue", "Dequeue", nullptr));
        labelDisplay->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class DialogQueue: public Ui_DialogQueue {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGQUEUE_H
