/********************************************************************************
** Form generated from reading UI file 'dialoggraph.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGGRAPH_H
#define UI_DIALOGGRAPH_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialoggraph
{
public:
    QPushButton *pushButtonVertices;
    QPushButton *pushButtonAristas;
    QLabel *labelDisplay;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLineEdit *lineEditData1;
    QLineEdit *lineEditData2;
    QLineEdit *lineEditData3;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButtonAtras;
    QPushButton *pushButtonBusquedaProfunda;
    QPushButton *pushButtonBusquedaAncha;
    QPushButton *pushButtonPrim;
    QPushButton *pushButtonWarshall;
    QPushButton *pushButtonKruskal;
    QPushButton *pushButtonDijkstra;
    QPushButton *pushButtonFloyd;

    void setupUi(QDialog *Dialoggraph)
    {
        if (Dialoggraph->objectName().isEmpty())
            Dialoggraph->setObjectName("Dialoggraph");
        Dialoggraph->resize(800, 600);
        pushButtonVertices = new QPushButton(Dialoggraph);
        pushButtonVertices->setObjectName("pushButtonVertices");
        pushButtonVertices->setGeometry(QRect(180, 70, 111, 24));
        pushButtonAristas = new QPushButton(Dialoggraph);
        pushButtonAristas->setObjectName("pushButtonAristas");
        pushButtonAristas->setGeometry(QRect(180, 130, 111, 24));
        labelDisplay = new QLabel(Dialoggraph);
        labelDisplay->setObjectName("labelDisplay");
        labelDisplay->setGeometry(QRect(270, 50, 501, 501));
        layoutWidget = new QWidget(Dialoggraph);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(50, 70, 110, 92));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        lineEditData1 = new QLineEdit(layoutWidget);
        lineEditData1->setObjectName("lineEditData1");

        verticalLayout->addWidget(lineEditData1);

        lineEditData2 = new QLineEdit(layoutWidget);
        lineEditData2->setObjectName("lineEditData2");

        verticalLayout->addWidget(lineEditData2);

        lineEditData3 = new QLineEdit(layoutWidget);
        lineEditData3->setObjectName("lineEditData3");

        verticalLayout->addWidget(lineEditData3);

        widget = new QWidget(Dialoggraph);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(40, 190, 140, 252));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButtonAtras = new QPushButton(widget);
        pushButtonAtras->setObjectName("pushButtonAtras");

        verticalLayout_2->addWidget(pushButtonAtras);

        pushButtonBusquedaProfunda = new QPushButton(widget);
        pushButtonBusquedaProfunda->setObjectName("pushButtonBusquedaProfunda");

        verticalLayout_2->addWidget(pushButtonBusquedaProfunda);

        pushButtonBusquedaAncha = new QPushButton(widget);
        pushButtonBusquedaAncha->setObjectName("pushButtonBusquedaAncha");

        verticalLayout_2->addWidget(pushButtonBusquedaAncha);

        pushButtonPrim = new QPushButton(widget);
        pushButtonPrim->setObjectName("pushButtonPrim");

        verticalLayout_2->addWidget(pushButtonPrim);

        pushButtonWarshall = new QPushButton(widget);
        pushButtonWarshall->setObjectName("pushButtonWarshall");

        verticalLayout_2->addWidget(pushButtonWarshall);

        pushButtonKruskal = new QPushButton(widget);
        pushButtonKruskal->setObjectName("pushButtonKruskal");

        verticalLayout_2->addWidget(pushButtonKruskal);

        pushButtonDijkstra = new QPushButton(widget);
        pushButtonDijkstra->setObjectName("pushButtonDijkstra");

        verticalLayout_2->addWidget(pushButtonDijkstra);

        pushButtonFloyd = new QPushButton(widget);
        pushButtonFloyd->setObjectName("pushButtonFloyd");

        verticalLayout_2->addWidget(pushButtonFloyd);


        retranslateUi(Dialoggraph);

        QMetaObject::connectSlotsByName(Dialoggraph);
    } // setupUi

    void retranslateUi(QDialog *Dialoggraph)
    {
        Dialoggraph->setWindowTitle(QCoreApplication::translate("Dialoggraph", "Dialog", nullptr));
        pushButtonVertices->setText(QCoreApplication::translate("Dialoggraph", "Insertar v\303\251rtice", nullptr));
        pushButtonAristas->setText(QCoreApplication::translate("Dialoggraph", "Insertar aristas", nullptr));
        labelDisplay->setText(QString());
        lineEditData1->setText(QString());
        pushButtonAtras->setText(QCoreApplication::translate("Dialoggraph", "Atras", nullptr));
        pushButtonBusquedaProfunda->setText(QCoreApplication::translate("Dialoggraph", "B\303\272squeda profunda", nullptr));
        pushButtonBusquedaAncha->setText(QCoreApplication::translate("Dialoggraph", "B\303\272squeda ancha", nullptr));
        pushButtonPrim->setText(QCoreApplication::translate("Dialoggraph", "Prim", nullptr));
        pushButtonWarshall->setText(QCoreApplication::translate("Dialoggraph", "Warshall", nullptr));
        pushButtonKruskal->setText(QCoreApplication::translate("Dialoggraph", "Kruskal", nullptr));
        pushButtonDijkstra->setText(QCoreApplication::translate("Dialoggraph", "Dijkstra", nullptr));
        pushButtonFloyd->setText(QCoreApplication::translate("Dialoggraph", "Floyd", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialoggraph: public Ui_Dialoggraph {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGGRAPH_H
