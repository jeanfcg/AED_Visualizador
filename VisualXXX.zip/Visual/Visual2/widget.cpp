#include "widget.h"
#include "./ui_widget.h"
#include "dialogqueue.h"
#include "dialogstack.h"
#include "dialoggraph.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    QImage image;
    image.load("LOGO_UNSA.png");

    ui->labelLogo->setAlignment(Qt::AlignCenter);
    ui->labelLogo->setPixmap(QPixmap::fromImage(image));
    ui->labelLogo->setScaledContents(true);

    QImage image2;
    image2.load("aprendiendo.png");

    ui->labelLogo2->setAlignment(Qt::AlignCenter);
    ui->labelLogo2->setPixmap(QPixmap::fromImage(image2));
    ui->labelLogo2->setScaledContents(true);

}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButtonQueue_clicked()
{
    DialogQueue* queue = new DialogQueue(this); //necesitamos asignarle un padre, por eso usamos this (this apunta al objeto actual)
    queue ->setModal(true);
    queue->show();
}

void Widget::on_pushButtonStack_clicked()
{
    DialogStack* stack = new DialogStack(this); //necesitamos asignarle un padre, por eso usamos this (this apunta al objeto actual)
    stack ->setModal(true);
    stack->show();
}


void Widget::on_pushButtonGraph_clicked()
{
    Dialoggraph* graph = new Dialoggraph(this); //necesitamos asignarle un padre, por eso usamos this (this apunta al objeto actual)
    graph ->setModal(true);
    graph->show();

}

