/********************************************************************************
** Form generated from reading UI file 'dialoggraph.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGGRAPH_H
#define UI_DIALOGGRAPH_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialoggraph
{
public:
    QPushButton *pushButtonVertices;
    QPushButton *pushButtonAristas;
    QPushButton *pushButtonBusquedaProfunda;
    QPushButton *pushButtonBusquedaAncha;
    QPushButton *pushButtonPrim;
    QPushButton *pushButtonWarshall;
    QPushButton *pushButtonKruskal;
    QPushButton *pushButtonDijkstra;
    QPushButton *pushButtonFloyd;
    QLabel *labelDisplay;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLineEdit *lineEditData1;
    QLineEdit *lineEditData2;
    QLineEdit *lineEditData3;

    void setupUi(QDialog *Dialoggraph)
    {
        if (Dialoggraph->objectName().isEmpty())
            Dialoggraph->setObjectName("Dialoggraph");
        Dialoggraph->resize(800, 600);
        pushButtonVertices = new QPushButton(Dialoggraph);
        pushButtonVertices->setObjectName("pushButtonVertices");
        pushButtonVertices->setGeometry(QRect(180, 70, 111, 24));
        pushButtonAristas = new QPushButton(Dialoggraph);
        pushButtonAristas->setObjectName("pushButtonAristas");
        pushButtonAristas->setGeometry(QRect(180, 130, 111, 24));
        pushButtonBusquedaProfunda = new QPushButton(Dialoggraph);
        pushButtonBusquedaProfunda->setObjectName("pushButtonBusquedaProfunda");
        pushButtonBusquedaProfunda->setGeometry(QRect(40, 230, 121, 24));
        pushButtonBusquedaAncha = new QPushButton(Dialoggraph);
        pushButtonBusquedaAncha->setObjectName("pushButtonBusquedaAncha");
        pushButtonBusquedaAncha->setGeometry(QRect(40, 260, 121, 24));
        pushButtonPrim = new QPushButton(Dialoggraph);
        pushButtonPrim->setObjectName("pushButtonPrim");
        pushButtonPrim->setGeometry(QRect(40, 290, 80, 24));
        pushButtonWarshall = new QPushButton(Dialoggraph);
        pushButtonWarshall->setObjectName("pushButtonWarshall");
        pushButtonWarshall->setGeometry(QRect(40, 320, 80, 24));
        pushButtonKruskal = new QPushButton(Dialoggraph);
        pushButtonKruskal->setObjectName("pushButtonKruskal");
        pushButtonKruskal->setGeometry(QRect(40, 360, 80, 24));
        pushButtonDijkstra = new QPushButton(Dialoggraph);
        pushButtonDijkstra->setObjectName("pushButtonDijkstra");
        pushButtonDijkstra->setGeometry(QRect(40, 400, 80, 24));
        pushButtonFloyd = new QPushButton(Dialoggraph);
        pushButtonFloyd->setObjectName("pushButtonFloyd");
        pushButtonFloyd->setGeometry(QRect(40, 440, 80, 24));
        labelDisplay = new QLabel(Dialoggraph);
        labelDisplay->setObjectName("labelDisplay");
        labelDisplay->setGeometry(QRect(390, 130, 371, 361));
        layoutWidget = new QWidget(Dialoggraph);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(50, 70, 110, 86));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        lineEditData1 = new QLineEdit(layoutWidget);
        lineEditData1->setObjectName("lineEditData1");

        verticalLayout->addWidget(lineEditData1);

        lineEditData2 = new QLineEdit(layoutWidget);
        lineEditData2->setObjectName("lineEditData2");

        verticalLayout->addWidget(lineEditData2);

        lineEditData3 = new QLineEdit(layoutWidget);
        lineEditData3->setObjectName("lineEditData3");

        verticalLayout->addWidget(lineEditData3);


        retranslateUi(Dialoggraph);

        QMetaObject::connectSlotsByName(Dialoggraph);
    } // setupUi

    void retranslateUi(QDialog *Dialoggraph)
    {
        Dialoggraph->setWindowTitle(QCoreApplication::translate("Dialoggraph", "Dialog", nullptr));
        pushButtonVertices->setText(QCoreApplication::translate("Dialoggraph", "Insertar v\303\251rtice", nullptr));
        pushButtonAristas->setText(QCoreApplication::translate("Dialoggraph", "Insertar aristas", nullptr));
        pushButtonBusquedaProfunda->setText(QCoreApplication::translate("Dialoggraph", "B\303\272squeda profunda", nullptr));
        pushButtonBusquedaAncha->setText(QCoreApplication::translate("Dialoggraph", "B\303\272squeda ancha", nullptr));
        pushButtonPrim->setText(QCoreApplication::translate("Dialoggraph", "Prim", nullptr));
        pushButtonWarshall->setText(QCoreApplication::translate("Dialoggraph", "Warshall", nullptr));
        pushButtonKruskal->setText(QCoreApplication::translate("Dialoggraph", "Kruskal", nullptr));
        pushButtonDijkstra->setText(QCoreApplication::translate("Dialoggraph", "Dijkstra", nullptr));
        pushButtonFloyd->setText(QCoreApplication::translate("Dialoggraph", "Floyd", nullptr));
        labelDisplay->setText(QString());
        lineEditData1->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialoggraph: public Ui_Dialoggraph {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGGRAPH_H
