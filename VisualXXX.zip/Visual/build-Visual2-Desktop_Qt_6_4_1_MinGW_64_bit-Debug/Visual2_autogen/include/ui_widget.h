/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *pushButtonQueue;
    QLabel *labelLogo;
    QLabel *labelLogo2;
    QPushButton *pushButtonStack;
    QPushButton *pushButtonGraph;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName("Widget");
        Widget->resize(800, 600);
        pushButtonQueue = new QPushButton(Widget);
        pushButtonQueue->setObjectName("pushButtonQueue");
        pushButtonQueue->setGeometry(QRect(70, 240, 80, 24));
        labelLogo = new QLabel(Widget);
        labelLogo->setObjectName("labelLogo");
        labelLogo->setGeometry(QRect(230, 60, 461, 411));
        labelLogo2 = new QLabel(Widget);
        labelLogo2->setObjectName("labelLogo2");
        labelLogo2->setGeometry(QRect(380, 180, 271, 231));
        pushButtonStack = new QPushButton(Widget);
        pushButtonStack->setObjectName("pushButtonStack");
        pushButtonStack->setGeometry(QRect(70, 320, 80, 24));
        pushButtonGraph = new QPushButton(Widget);
        pushButtonGraph->setObjectName("pushButtonGraph");
        pushButtonGraph->setGeometry(QRect(70, 390, 80, 24));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "App", nullptr));
        pushButtonQueue->setText(QCoreApplication::translate("Widget", "Queue", nullptr));
        labelLogo->setText(QString());
        labelLogo2->setText(QString());
        pushButtonStack->setText(QCoreApplication::translate("Widget", "Stack", nullptr));
        pushButtonGraph->setText(QCoreApplication::translate("Widget", "Grafos", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
